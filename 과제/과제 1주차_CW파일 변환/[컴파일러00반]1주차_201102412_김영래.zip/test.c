//----- ��� : ���ϸ� test.c -----

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void main()
{
	int i = 0;
	char n[] = "abc";
	char m[] = "def";

	printf("yeonglae\n");
	printf("%s\n", n );
	for(i=0; i<2; i++)
	{
		printf("%s ", m);
	}

	printf("\n");

	printf("%s\n", m );
	printf(",\n");
	printf("Hello\n");
	for(i=0; i<3; i++)
	{
		printf("CSE");

		if(i!=2)	printf(", ");
	}

	printf("\n");

	for(i=0; i<4; i++)
	{
		printf("def");

		if(i!=3)	printf(", ");
	}

	printf("\n");

	printf("Kim");


		printf(", ");

	printf("%s\n", n);

}