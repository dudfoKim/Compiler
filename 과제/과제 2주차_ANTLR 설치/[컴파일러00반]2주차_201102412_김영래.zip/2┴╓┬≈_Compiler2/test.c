int x;

void test(int a)
{
	int k;
	k = 5;
	while(true){
		if(a==7)
		{
			break;
		}
		a = a+1;
	}
	k = k + a;
	return k;
}