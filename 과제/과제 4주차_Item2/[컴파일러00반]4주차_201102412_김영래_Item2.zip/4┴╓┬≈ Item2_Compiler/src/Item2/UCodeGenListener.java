package Item2;

import java.util.*;
import org.antlr.v4.runtime.tree.ParseTreeProperty;

public class UCodeGenListener extends MiniCBaseListener
{
	ParseTreeProperty<String> newTexts = new ParseTreeProperty<String>();
	HashMap<String, String> table = new HashMap<String, String>();
	List<Integer> list = new ArrayList<Integer>();

	String eleven = "           ";
	String eight = "        ";
	String three = "   ";
	String two = "  ";
	int compoundCount = 0;
	int lexicalLevel = 0;
	int blockLevel = 0;
	int globalCount = 0;
	int localCount = 0;
	int tempCount = 0;
	int blinkCount = 0;
	int i = 0;
	int temp = 0;
	int param = 0;
	int globalLabel = -1;
	int functionIndex = 0;
	
	boolean isBinaryOperation(MiniCParser.ExprContext ctx)
	{
		return ctx.getChildCount() == 3 && ctx.getChild(1) != ctx.expr(0);
	}
   
   @Override 
   public void enterProgram(MiniCParser.ProgramContext ctx)
   {
	   blockLevel++;
	   System.out.println();
   }

   @Override 
   public void exitProgram(MiniCParser.ProgramContext ctx) 
   { 
	   int count = ctx.decl().size();	   
	   lexicalLevel = 1;
	   
	   String result = eleven + "bgn" + three + 0 + "\n";;
	   String decl = newTexts.get(ctx.decl(0));
      
	   for(i=1; i<count; i++)
	   {
		   decl +="\n"+ newTexts.get(ctx.decl(i));
	   }

	   result += eleven + "proc" + two + globalCount + two + blockLevel + two + lexicalLevel + "\n" + decl + eleven + "\n" + eleven + "end"+ "\n";
	   System.out.print(result);
   }

   @Override
   public void exitDecl(MiniCParser.DeclContext ctx) 
   { 
      String result = null;

      if(ctx.getChild(0).equals(ctx.var_decl()))
      { 
    	  result = newTexts.get(ctx.var_decl());
    	  newTexts.put(ctx, result);
      }
      else
      {
    	  result = newTexts.get(ctx.fun_decl());
    	  newTexts.put(ctx, result);
      }
   }
   
   @Override
   public void enterVar_decl(MiniCParser.Var_declContext ctx)
   {
	   String varValue = ctx.IDENT().getText();
	   
	   if(ctx.getChildCount() == 3)
	   {
		   globalCount++;

		   table.put(varValue, blockLevel + two + globalCount);
	   }
      	else
      	{
      		int size = Integer.parseInt(ctx.LITERAL().getText());
         
         	globalCount += size;
         	temp = globalCount - size+1;
         
         table.put(varValue, blockLevel + two + globalCount);
      	}
   }
   
   @Override
   public void exitVar_decl(MiniCParser.Var_declContext ctx) 
   {
	   	if(ctx.getChildCount()==3)
	   	{
	   		newTexts.put(ctx, eleven + "sym" + three + blockLevel + two + globalCount + two + 1);
	   	}
	   	else 
	   	{
	   		int size = Integer.parseInt(ctx.LITERAL().getText());
	   		int temp ;
         
	   		temp = globalCount - size+1;
	   		newTexts.put(ctx, eleven + "sym" + three + blockLevel + two + temp + two + size);
	   	}
   	}

   @Override 
   public void exitType_spec(MiniCParser.Type_specContext ctx) 
   { 
	   if(ctx.getChild(0)==ctx.VOID())
	   {
		   newTexts.put(ctx, ctx.VOID().getText());
	   }
	   else
	   {
		   newTexts.put(ctx, ctx.INT().getText());
	   }
   }
   
   @Override
   public void enterFun_decl(MiniCParser.Fun_declContext ctx) 
   {
	   blockLevel++;
	   functionIndex++;
   }

   @Override 
   public void exitFun_decl(MiniCParser.Fun_declContext ctx) 
   {
	   	String indent = null;
	   	String compound_stmt = null;
	   	indent =ctx.IDENT().getText();
	 	compound_stmt = newTexts.get(ctx.compound_stmt());

	 	for(i=indent.length(); i<11;i++)
	 	{
	 		indent += " ";
	 	}

	 	localCount += list.get(functionIndex-1);
	 	System.out.print(indent + "proc" + two + localCount + two + blockLevel + two + lexicalLevel + "\n");
	 	System.out.print(compound_stmt + eleven + "end\n");

	 	blockLevel--;
	 	newTexts.put(ctx, eleven + "ldp\n" + eleven + "call" + three + indent);
   }

   @Override
   public void enterParams(MiniCParser.ParamsContext ctx)
   {
	   list.add(ctx.param().size());
   }

   @Override
   public void exitParams(MiniCParser.ParamsContext ctx) 
   {
	 	String param = newTexts.get(ctx.param(0));
	 	int param_cnt = ctx.param().size();
      
	 	for(i=1; i<param_cnt ; i++)
	 	{
	 		param += "," + newTexts.get(ctx.param(i));
	 	}
      
	 	if(ctx.getChildCount()==0)
	 	{
	 		newTexts.put(ctx, "");
	 	}
	 	else if(ctx.getChild(0).getText().equals("void"))
	 	{
	 		newTexts.put(ctx, "void");
	 	}
	 	else
	 	{ 
	 		newTexts.put(ctx, param);
	 	}
   	}
   
   	@Override
   	public void exitParam(MiniCParser.ParamContext ctx) 
   	{ 
   		String type_spec = null;
   		String indent = null;
   		
   		type_spec = newTexts.get(ctx.type_spec());
   		indent = ctx.IDENT().getText();
      
   		if(ctx.getChildCount()==2)
   		{
   			newTexts.put(ctx, type_spec + " " + indent);
   		}
   		else 
   		{
   			newTexts.put(ctx, type_spec + " " + indent + "[]");
   		}
   	}

   	@Override
   	public void exitStmt(MiniCParser.StmtContext ctx) 
   	{ 
   		String result = null;
   		
   		if(ctx.getChild(0).equals(ctx.expr_stmt()))
   		{
   			result = newTexts.get(ctx.expr_stmt());
   			newTexts.put(ctx, result);
   		}
   		else if(ctx.getChild(0).equals(ctx.compound_stmt()))
   		{	
   			result = newTexts.get(ctx.compound_stmt());
   			newTexts.put(ctx, result);
   		}
   		else if(ctx.getChild(0).equals(ctx.if_stmt()))
   		{
   			result = newTexts.get(ctx.if_stmt());
   			newTexts.put(ctx, result);
   		}
   		else if(ctx.getChild(0).equals(ctx.while_stmt()))
   		{
   			result = newTexts.get(ctx.while_stmt());
   			newTexts.put(ctx, result);
   		}
   		else if(ctx.getChild(0).equals(ctx.return_stmt()))
   		{
   			result = newTexts.get(ctx.return_stmt());
   			newTexts.put(ctx, result);
   		}	
   	}
   
   	@Override
   	public void exitExpr_stmt(MiniCParser.Expr_stmtContext ctx) 
   	{ 
   		String expr = null;
   		
   		expr = newTexts.get(ctx.expr());
   		newTexts.put(ctx, expr);
   	}

   	@Override
   	public void enterWhile_stmt(MiniCParser.While_stmtContext ctx) 
   	{
     	blockLevel++;
     	globalLabel++;
   	}

   	@Override
   	public void exitWhile_stmt(MiniCParser.While_stmtContext ctx)
   	{
   		String tempWhile = "$$" + globalLabel;
   		String expr = "";
   		String stmt = "";
   		String temp = "";
   		String mark = "$$" + (globalLabel+1);
   		String resultBlink = mark;

   		int tempIndent = 11 - tempWhile.length();

   		for(i=0; i<tempIndent; i++)
   		{
   			tempWhile += " ";
   		}

   		int tempBlink = 11 - mark.length();
   		
   		for(i=0; i<tempBlink; i++)
   		{
   			resultBlink += " ";
   		}

   		tempWhile += "nop\n";
   		expr = newTexts.get(ctx.expr()) + eleven + "fjp" + three + mark + "\n";
   		stmt = newTexts.get(ctx.stmt());

   		if(!(ctx.stmt().getChild(0) instanceof MiniCParser.Compound_stmtContext)) 
   		{
   			temp += tempWhile + expr + stmt + "ujp";
   			newTexts.put(ctx, temp + three + "$$" + globalLabel + "\n" + resultBlink + "nop\n");
   		}
   		else
   		{
   			temp += tempWhile + expr + stmt + eleven + "ujp";
   			newTexts.put(ctx, temp + three + "$$" + globalLabel + "\n" + resultBlink + "nop\n");
   		}

   		blockLevel--;
   	}

   	@Override
   	public void enterCompound_stmt(MiniCParser.Compound_stmtContext ctx) 
   	{
   		compoundCount++;
   		tempCount = localCount;
   		localCount = 0;
   	}

   	@Override
   	public void exitCompound_stmt(MiniCParser.Compound_stmtContext ctx) 
   	{ 
   		String local_decl = newTexts.get(ctx.local_decl(0));
   		String stmt = newTexts.get(ctx.stmt(0));
   		lexicalLevel = 2;
   		
   		int localSize = ctx.local_decl().size();
   		int stmtSize = ctx.stmt().size();
      
   		for(i=1; i<localSize ; i++)
   		{
   			local_decl += newTexts.get(ctx.local_decl(i));
   		}
      
   		for(i=1; i<stmtSize ; i++)
   		{
   			stmt += newTexts.get(ctx.stmt(i));
   		}
      
   		if(localSize==0 && stmtSize == 0)
   		{
   			newTexts.put(ctx, "");
   		}
   		else if(localSize!=0 && stmtSize==0)
   		{
   			newTexts.put(ctx, local_decl);
   		}
   		else if(localSize==0 && stmtSize!=0)
   		{
   			newTexts.put(ctx, stmt);
   		}
   		else 
   		{
   			newTexts.put(ctx, local_decl + stmt);
   		}

   		if(compoundCount>1)
   		{
   			localCount = tempCount;
   		}

   		compoundCount--;
   	}

   	@Override
   	public void enterLocal_decl(MiniCParser.Local_declContext ctx)
   	{
   		String indent = null;
   		indent = ctx.IDENT().getText();

   		if(ctx.getChildCount() == 3)
   		{
   			localCount++;

   			table.put(indent, blockLevel + two + localCount);
   		}
   		else
   		{
   			int size = Integer.parseInt(ctx.LITERAL().getText());

         	localCount += size;

   			table.put(indent, blockLevel + two + localCount);
   		}
   	}
   
   	@Override
   	public void exitLocal_decl(MiniCParser.Local_declContext ctx) 
   	{ 
   		String indent = ctx.IDENT().getText();

   		if(ctx.getChildCount() == 3)
   		{
   			newTexts.put(ctx, eleven + "sym" + three + blockLevel + two + localCount + two + "1" + "\n");

   			table.put(indent, blockLevel + two + localCount);
   		}
   		else
   		{
   			int size = Integer.parseInt(ctx.LITERAL().getText());
   			int start = 0;
         
   			start = localCount - size+1;
   			newTexts.put(ctx, eleven + "sym" + three + blockLevel + two + start + two + size + "\n");
   			
   			table.put(indent, blockLevel + two + start);
   		}
   	}

   	@Override 
   	public void enterIf_stmt(MiniCParser.If_stmtContext ctx) 
   	{
   		blockLevel++;
   		globalLabel++;
   	}

   	@Override
   	public void exitIf_stmt(MiniCParser.If_stmtContext ctx) 
   	{
   		String tempWhile = "$$" + globalLabel;
   		String expr = "";
   		String stmt = "";
   		String stmt2 = "";
   		String temp = "";
   		String mark = "$$" + (globalLabel+1);
   		String resultBlink = mark;

   		int tempIndent = 11 - tempWhile.length();

   		for(i=0; i<tempIndent; i++)
   		{
   			tempWhile += " ";
   		}

   		int tempBlink = 11 - mark.length();
   		
   		for(i=0; i<tempBlink; i++)
   		{
   			resultBlink += " ";
   		}

   		tempWhile += "nop\n";
   		expr = newTexts.get(ctx.expr()) + eleven + "fjp" + three + mark + "\n";
   		stmt = newTexts.get(ctx.stmt(0));
   		stmt2 = newTexts.get(ctx.stmt(1));

   		if(ctx.getChildCount()==5)
   		{
   			if(!(ctx.stmt(0).getChild(0) instanceof MiniCParser.Compound_stmtContext)) 
   			{
   				temp += tempWhile + expr + stmt + mark;
   				newTexts.put(ctx, temp + "$$" + globalLabel + "nop\n");
   			}
   			else
   			{
   				temp += tempWhile + expr + stmt + mark;
   				newTexts.put(ctx, temp + eight + "nop\n");
   			}
   		}
   		else
   		{
   			if(!(ctx.stmt(0).getChild(0) instanceof MiniCParser.Compound_stmtContext)) 
   			{
   				temp += tempWhile + expr + stmt + resultBlink + "nop\n" + stmt2;
   				newTexts.put(ctx, temp);
   			}
   			else
   			{
   				temp += tempWhile + expr + stmt + resultBlink + "nop\n" + stmt2;
   				newTexts.put(ctx, temp);
   			}
   		}
   		
   		blockLevel--;
   	}

   	@Override 
   	public void exitReturn_stmt(MiniCParser.Return_stmtContext ctx) 
   	{
   		String temp = ctx.RETURN().getText();
   		String expr = "";

	   	if(ctx.getChildCount()==2)
	   {
		   newTexts.put(ctx, eleven + "ret\n");
   	  	}
	   else
	   {
		   expr += newTexts.get(ctx.expr());

		   if(table.containsKey(expr))
		   {
			   String returnExpr = table.get(expr);
			   newTexts.put(ctx, eleven + "lod" + three + returnExpr + "\n" + eleven + "retv\n");
		   }
		   else
		   {
			   newTexts.put(ctx, eleven + "retv" + three + expr + "\n");
		   }
	   }
   	}
   
   	@Override
   	public void exitExpr(MiniCParser.ExprContext ctx)
   	{ 
   		String expr1 = null;
   		String expr2 = null;
   		String op = null;
   		String indent  = null;
   		String args = null;

   		if(isBinaryOperation(ctx))
   		{
   			if(ctx.getChild(0)==ctx.IDENT())
   			{
   				indent = table.get(ctx.IDENT().getText());
   				expr1 = newTexts.get(ctx.expr(0));

   				if(ctx.expr(0).getChildCount()==1)
   				{
   					newTexts.put(ctx, eleven + "ldc" + three + expr1 + "\n" + eleven + "str" + three + indent + "\n");
   				}
   				else
   				{
   					newTexts.put(ctx, expr1 + eleven + "str" + three + indent + "\n");
   				}	
   			}
   			else
   			{
   				expr1 = newTexts.get(ctx.expr(0));
   				expr2 = newTexts.get(ctx.expr(1));
   				
 				String temp1 = table.get(expr1);
   				String temp2 = table.get(expr2);

   				op = ctx.getChild(1).getText();
   				String calc = null;
            
   				if(op.equals("+"))
   				{
   					calc = "add";
   				}
   				else if(op.equals("-"))
   				{
   					calc = "sub";
   				} 
   				else if(op.equals("*"))
   				{
   					calc = "mult";
   				}
   				else if(op.equals("/"))
   				{
   					calc = "div";
   				} 
   				else if(op.equals("%"))
   				{
   					calc = "mod";
   				}
   				else if(op.equals("or"))
   				{
   					calc = "or";
   				} 
   				else if(op.equals("and"))
   				{
   					calc = "and";
   				} 
   				else if(op.equals("<="))
   				{
   					calc = "le";
   				}
   				else if(op.equals(">="))
   				{
   					calc = "ge";
   				} 
   				else if(op.equals(">"))
   				{
   					calc = "gt";
   				} 
   				else if(op.equals("<"))
   				{
   					calc = "lt";
   				} 
   				else if(op.equals("=="))
   				{
   					calc = "eq";
   				} 
   				else if(op.equals("!="))
   				{
   					calc = "ne";
   				}
   				if(table.containsKey(expr1)==true && table.containsKey(expr2)==true)
   				{
   					newTexts.put(ctx, eleven + "lod" + three + temp1 + "\n" + eleven + "lod" + three + temp2 + "\n" + eleven + calc + "\n" );
   				}
   				else if(table.containsKey(expr1)==false && table.containsKey(expr2)==true)
   				{
   					if(ctx.expr(0).getChildCount()!=1)
   					{
   						newTexts.put(ctx, expr1 + eleven + "lod" + three + temp2 + "\n" + eleven + calc + "\n");
   					}
   					else
   					{
   						newTexts.put(ctx, eleven + "ldc" + three + expr1 + "\n" + eleven + "lod" + three + temp2 + "\n" + eleven + calc + "\n" );
   					}
   				}
   				else if(table.containsKey(expr1)==true && table.containsKey(expr2)==false)
   				{
   					if(ctx.expr(1).getChildCount()!=1)
   					{
   						newTexts.put(ctx, eleven + "lod" + three + temp1 + "\n" + temp2 + eleven + calc + "\n");
   					}
   					else
   					{
   						newTexts.put(ctx, eleven + "lod" + three + temp1 + "\n" + eleven + "ldc" + three + expr2 + "\n" + eleven + calc + "\n" );
   					}
   				}
   				else
   				{
   					String paren = "";

   					if(ctx.expr(0).getChildCount()==1 && ctx.expr(0).getChildCount()==1)
   					{
   						paren += eleven + "ldc" + three + expr1 + "\n" + eleven + "ldc" + three + expr2 + "\n" + eleven + calc + "\n"	;
   						
   						newTexts.put(ctx, paren);
   					}
   					else if(ctx.expr(0).getChildCount()!=1 && ctx.expr(0).getChildCount()==1)
   					{
   						paren = expr1 + "\n" + eleven + "ldc" + three + expr2 + "\n" + eleven + calc + "\n";

   						newTexts.put(ctx, paren);
   					}
   					else if(ctx.expr(0).getChildCount()==1 && ctx.expr(0).getChildCount()!=1)
   					{
   						paren = eleven + "ldc" + three + expr1 + "\n" + expr2 + eleven + calc + "\n";
   						
   						newTexts.put(ctx, paren);
   					}
   					else
   					{
   						paren = expr1 + expr2 + eleven + calc + "\n";
   						
   						newTexts.put(ctx, paren);
					}
   				}
   			}
   		}
   		else if(ctx.getChildCount()==3)
   		{
   			expr1 = newTexts.get(ctx.expr(0));
         	newTexts.put(ctx, expr1);
   		}
   		else if (ctx.getChildCount()==4 && ctx.getChild(2)==ctx.expr())
   		{
   			indent = ctx.IDENT().getText();
   			expr1 = newTexts.get(ctx.expr(0));
   			newTexts.put(ctx, indent+"[" + expr1 + "]");
   		}
   		else if (ctx.getChildCount()==4 && ctx.getChild(2)==ctx.args())
   		{
   			indent = ctx.IDENT().getText();
   			args = newTexts.get(ctx.args());
   			String temp = table.get(args);
   			
   			if(ctx.getChild(2).getChildCount()==0)
   			{
   				newTexts.put(ctx, eleven + "ldp\n" + eleven + "call" + three + indent);
   			} 
   			else
   			{
   				newTexts.put(ctx, eleven + "ldp\n" + eleven + "lod" + three + temp + "\n" + eleven + "call" + three + indent + "\n");
   			}
   		}
   		else if(ctx.getChildCount()==2)
      	{
   			expr1 = newTexts.get(ctx.expr(0));
         
   			if(ctx.getChild(0).equals("!"))
   			{
   				newTexts.put(ctx, "!"+expr1);
   			}
   			else if(ctx.getChild(0).equals("-"))
         	{
   				newTexts.put(ctx, "-"+expr1);
         	}
   			else
   			{
   				newTexts.put(ctx, "+"+expr1);
   			}
      	}
   		else if(ctx.getChildCount() == 6)
   		{
   			indent = ctx.IDENT().getText();
   			expr1 = newTexts.get(ctx.expr(0));
   			expr2 = newTexts.get(ctx.expr(1));
         
   			newTexts.put(ctx, indent + "[" + expr1 + "]" + " = " + expr2);
   		}
   		else 
      	{
   			newTexts.put(ctx, ctx.getChild(0).getText());
      	}
   	}

   	@Override
   	public void exitArgs(MiniCParser.ArgsContext ctx)
   	{
	  	int count = ctx.expr().size();
	  	String expr = newTexts.get(ctx.expr(0));
	  	
	  	for(i=1; i<count ; i++)
	  	{
	  		expr += newTexts.get(ctx.expr(i));
	  	}
	   
	  	newTexts.put(ctx, expr);
   	}
}