package Compiler3;

import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeProperty;

public class MiniCPrintListener extends MiniCBaseListener
{
	ParseTreeProperty<String> newTexts = new ParseTreeProperty<String>();
	int i = 0;
	int j = 0;
	int indentNum = 0;

	boolean isBinaryOperation(MiniCParser.ExprContext ctx)
	{
		return ctx.getChildCount()==3 && ctx.getChild(1)!= ctx.expr(0);
	}

	@Override 
	public void exitProgram	(MiniCParser.ProgramContext ctx)
	{
		for(i=0; i<ctx.getChildCount(); i++)
		{
			System.out.println(newTexts.get(ctx.decl(i)));
		}
	}

	@Override 
	public void exitDecl(MiniCParser.DeclContext ctx) 
	{ 
		String result = null;

		if(ctx.getChild(0)==ctx.var_decl())
		{
			result = newTexts.get(ctx.var_decl());
			newTexts.put(ctx, result);
		}
		else
		{
			result = newTexts.get(ctx.fun_decl());
			newTexts.put(ctx, result);
		}
	}

	@Override
	public void exitVar_decl(MiniCParser.Var_declContext ctx) 
	{ 
		String spec = newTexts.get(ctx.type_spec());
		String ident = ctx.getChild(1).getText();
		
		if(ctx.getChildCount()==3)
		{
			newTexts.put(ctx, spec + " " + ident + ";\n");
		}
		else
		{
			newTexts.put(ctx, spec + " " + ident + "[];\n");
		}
	}

	@Override 
	public void exitType_spec(MiniCParser.Type_specContext ctx) 
	{ 
		newTexts.put(ctx, ctx.getText());
	}

	@Override
	public void exitFun_decl(MiniCParser.Fun_declContext ctx)
	{
		String spec = newTexts.get(ctx.type_spec());
		String ident = ctx.getChild(1).getText();
		String params = newTexts.get(ctx.params());
		String compound = newTexts.get(ctx.compound_stmt());
	
		newTexts.put(ctx, spec + " " + ident + " (" + params + ")" + compound + "\n");
	}

	@Override
	public void exitParams(MiniCParser.ParamsContext ctx)
	{ 
		String result = "";

		if(ctx.getChildCount()==1)
		{
			if(ctx.getChild(0)==ctx.VOID())
			{
				newTexts.put(ctx, "void");
			}
			else
			{
				result +=  ctx.param() + "";
				newTexts.put(ctx, result);
			}
		}
		else
		{
			i = 0;
			
			while(ctx.param(i+1)!=null)
			{
				result += newTexts.get(ctx.param(i)) + ", ";
				i++;
			}

			result += newTexts.get(ctx.param(i));
			newTexts.put(ctx, result);
		}
	}

	@Override
	public void exitParam(MiniCParser.ParamContext ctx) 
	{
		String spec = newTexts.get(ctx.type_spec());
		String ident = ctx.getChild(1).getText();

		if(ctx.getChildCount()==2)
		{
			newTexts.put(ctx, spec + " " + ident);
		}
		else
		{
			newTexts.put(ctx, spec + " " + ident + "[]");
		}
	}

	@Override
	public void exitStmt(MiniCParser.StmtContext ctx) 
	{
		String result = null;

		if(ctx.getChild(0)==ctx.expr_stmt())
		{
			result = newTexts.get(ctx.expr_stmt());
		}
		else if(ctx.getChild(0)==ctx.compound_stmt())
		{
			result = newTexts.get(ctx.compound_stmt());
		}
		else if(ctx.getChild(0)==ctx.if_stmt())
		{
			result = newTexts.get(ctx.if_stmt());
		}
		else if(ctx.getChild(0)==ctx.while_stmt())
		{
			result = newTexts.get(ctx.while_stmt());
		}
		else if(ctx.getChild(0)==ctx.return_stmt())
		{
			result = newTexts.get(ctx.return_stmt());
		}
		
		newTexts.put(ctx, result);
	}

	@Override
	public void exitExpr_stmt(MiniCParser.Expr_stmtContext ctx) 
	{
		String result = newTexts.get(ctx.expr());;
		
		newTexts.put(ctx, result + ";");
	}

	@Override 
	public void exitWhile_stmt(MiniCParser.While_stmtContext ctx) 
	{ 
		String result = "";

		result += " (" + newTexts.get(ctx.expr()) + ")";
		result += newTexts.get(ctx.stmt());
		newTexts.put(ctx, "while" + result);
	}

	@Override
	public void enterCompound_stmt(MiniCParser.Compound_stmtContext ctx)
	{
		indentNum++;

		newTexts.put(ctx, "\n");
	}

	@Override 
	public void exitCompound_stmt(MiniCParser.Compound_stmtContext ctx) 
	{
		int i = 0;
		String indent = "";

		for(j=1; j<indentNum; j++)
		{
			indent += "    ";
		}

		String result = "";
		result+="\n" + indent + "{";

		while(ctx.local_decl(i)!=null)
		{
			result += "\n    " + indent  + newTexts.get(ctx.local_decl(i));
	         i++;
		}

		i = 0;

		while(ctx.stmt(i)!=null)
		{
			result += "\n    " + indent + newTexts.get(ctx.stmt(i));
	         i++;
		}

		result += "\n" + indent + "}";
		indentNum--;
		newTexts.put(ctx, result);
	}

	@Override
	public void exitLocal_decl(MiniCParser.Local_declContext ctx) 
	{ 
		String spec = null;
		String ident = null;
		
		 if(ctx.getChildCount()==3)
		{
			spec = newTexts.get(ctx.type_spec());
			ident = ctx.getChild(1).getText();
				
			newTexts.put(ctx, spec+ " " + ident + ";");
		}
		 else
		{
			spec = newTexts.get(ctx.type_spec());
			ident = ctx.getChild(1).getText();
			
			newTexts.put(ctx, spec+ " " +  ident + "[];");
		}
	}

	@Override
	public void enterIf_stmt(MiniCParser.If_stmtContext ctx) 
	{
		if(!(ctx.stmt(0).getChild(0) instanceof MiniCParser.Compound_stmtContext))
		{
			indentNum++;
		}
	}

	@Override
	public void exitIf_stmt(MiniCParser.If_stmtContext ctx) 
	{
		String expr = null;
		String elsestore = null;
		String stmt1 = null;
		String stmt2 = null;
		String indent = "";

		if(ctx.getChildCount()>5)
		{
			expr = newTexts.get(ctx.expr());
			elsestore = ctx.getChild(5).getText();
			stmt1 = newTexts.get((ParseTree) ctx.stmt(0));
			stmt2 = newTexts.get((ParseTree) ctx.stmt(1));

			newTexts.put(ctx, "if " + expr + " " + stmt1 + " " + elsestore + " " + stmt2);
		}
		else
		{
			if(!(ctx.stmt(0).getChild(0) instanceof MiniCParser.Compound_stmtContext))
			{
				for(j=1; j<=indentNum; j++)
				{
					indent += "    ";
				}

				indentNum--;
				expr = newTexts.get(ctx.expr());
				stmt1 = newTexts.get(ctx.stmt(0));

				newTexts.put(ctx, "if (" + expr + ")\n" + indent + stmt1 +"\n");
			}
			else
			{
				expr = newTexts.get(ctx.expr());
			
			stmt1 = newTexts.get(ctx.getChild(4));

			newTexts.put(ctx, "if (" + expr + ")" + stmt1 +"\n");
			}
		}
	}

	@Override
	public void exitReturn_stmt(MiniCParser.Return_stmtContext ctx) 
	{
		String result = null;

		if(ctx.getChildCount()>2)
		{
			result = newTexts.get(ctx.expr());

			newTexts.put(ctx, "return " + result + ";");
		}
		else if(ctx.getChildCount()==2)
		{
			result = newTexts.get(ctx.expr());
			newTexts.put(ctx, "return;");
		}
	}

	@Override
	public void exitExpr(MiniCParser.ExprContext ctx)
	{
		String s1 = null;
		String s2 = null;
		String s3 = null;
		String op = null;

		if(isBinaryOperation(ctx))
		{
			if(ctx.expr(1)!=null)
			{
				s1 = newTexts.get(ctx.expr(0));
	            s2 = newTexts.get(ctx.expr(1));
	            op = ctx.getChild(1).getText();

	            newTexts.put(ctx, s1 + " " + op + " " + s2);   
	         }
			else
	         {
	            s1 = ctx.getChild(0).getText();
	            s2 = newTexts.get(ctx.expr(0));
	            op = ctx.getChild(1).getText();
	            
	            newTexts.put(ctx, s1 + " " + op + " " + s2);   
	         }
		}
		else if(ctx.getChildCount()==3)
		{
			newTexts.put(ctx, "(" + newTexts.get(ctx.expr(0)) + ")");
		}
		if(ctx.getChildCount()==1)
		{
			newTexts.put(ctx, ctx.getChild(0).getText());
		}
		else if(ctx.getChildCount()==2)
		{
			s2 = newTexts.get(ctx.expr(0));
			op = ctx.getChild(0).getText();

			newTexts.put(ctx, op + s2);
		}
		else if(ctx.getChildCount()==4)
		{
			s1 = ctx.getChild(0).getText();

			if(ctx.getChild(2)==ctx.expr(0))
			{
				s2 = "[" + newTexts.get(ctx.expr(0)) + "]";
			}
			else
			{
				s2 = "(" + newTexts.get(ctx.args()) + ")";
			}
	         
			newTexts.put(ctx, s1 + s2);
		}
		else if(ctx.getChildCount()==6)
		{
            s1 = ctx.getChild(0).getText();
            s2 = newTexts.get(ctx.expr(0));
            s3 = newTexts.get(ctx.expr(1));
            
            newTexts.put(ctx, s1 + "[" + s2 + "] = " + s3);   
		}
	}

	@Override 
	public void exitArgs(MiniCParser.ArgsContext ctx) 
	{
		String result = "";
		
		if(ctx.getChildCount()==0)
		{
			newTexts.put(ctx, "");
		}
		else
		{
			i = 0;
			
			while(ctx.expr(i+1)!=null)
			{
				result += newTexts.get(ctx.expr(i)) + ", ";
				i++;
			}
			
			result += newTexts.get(ctx.expr(i));
			newTexts.put(ctx, result);
		}
	}
}